

#include "F FrequentFlyerAccount.h"
//#include "main.cpp"
#include <iostream>
#include <string>
using namespace std;

//constructor
FrequentFlyerAccount::FrequentFlyerAccount(string name): mName(name)
{ }

//default constructor
FrequentFlyerAccount::FrequentFlyerAccount(): mName("")
{ }

//get data from account
double FrequentFlyerAccount::getBalance()
{
    
    return mBalance = 0.00;
}

string FrequentFlyerAccount::getName()
{
    return mName;
}

//determine whether customer has a frequent flyer account
bool FrequentFlyerAccount::addFlightToAccount(PlaneFlight flight)
{
   
    if (flight.getName() == getName())
    {
        //update account balance
        mBalance = mBalance + flight.getMileage();
        return true;
        
    }
    else
        return false;
}

//determine whether or not a free flight can be earned
bool FrequentFlyerAccount::canEarnFreeFlight(double mileage)
{
    if (mileage <= mBalance)
    {
        return true;
    }
    else
        return false;
}

//apply free flight to account
bool FrequentFlyerAccount::freeFlight(string from, string to, double mileage, PlaneFlight& flight)
{
    if (canEarnFreeFlight(mileage) == true)
    {
        //subract free flight mileage from account
        mBalance -= mileage;
        
        //create flight
        flight.setMileage(mileage);
        flight.setFromCity(from, to);
        flight.setToCity (to);
        flight.setCost(0.00);
        
        return true;
    }
    else
    {
        return false;
    }
}

