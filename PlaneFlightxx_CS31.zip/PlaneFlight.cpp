
#include "PlaneFlight.h"
#include <iostream>
#include <string>

//constructor
PlaneFlight::PlaneFlight(string passengerName, string fromCity, string toCity, double cost, double mileage): mName(passengerName), mFromCity(fromCity), mToCity(toCity), mCost(cost), mMileage(mileage)
{
    setName(passengerName);
    setFromCity(fromCity, toCity);
    setToCity(toCity);
    setCost(cost);
    setMileage(mileage);
    
}
//default constructor
PlaneFlight::PlaneFlight(): mName(""), mFromCity(""), mToCity(""),  mCost(0), mMileage(0)
{ }

//get data from flight
string PlaneFlight::getName()
{
    return mName;
}

string PlaneFlight::getFromCity()
{
    return mFromCity;
}

string PlaneFlight::getToCity()
{
    return mToCity;
}

double PlaneFlight::getCost()
{
    return mCost;
}

double PlaneFlight::getMileage()
{
    return mMileage;
}

//validate data and set values
void PlaneFlight::setCost(double cost)
{
    if (cost < 0)
    {
        cost = -1;
    }
    else
        mCost = cost;
}

void PlaneFlight::setMileage(double mileage)
{
    if (mileage <= 0)
    {
        mileage = -1;
    }
    else
        mMileage = mileage;
}

void PlaneFlight::setName(string name)
{
    if (name == "")
    {
        mName = getName();
    }
    else
        mName = name;
    
}

void PlaneFlight::setFromCity(string from, string to)
{
    if ((from == "") || (from == to))
    {
        mFromCity = getFromCity();
    }
    else
        mFromCity = from;
}

void PlaneFlight::setToCity(string to)
{
    if (to == "")
    {
        mToCity = getToCity();
    }
    else
        mToCity = to;
}


        
        
