
//

#ifndef F_FREQUENTFLYER_H
#define F_FREQUENTFLYER_H
#include "PlaneFlight.h"
#include <iostream>
#include <string>
using namespace std;

class FrequentFlyerAccount
{
private:
    string mName;
    double mBalance;

public:
    
    FrequentFlyerAccount(string name);
    
    FrequentFlyerAccount();
    
    
    double getBalance();
    string getName();
    
    bool addFlightToAccount(PlaneFlight flight);
    
    bool canEarnFreeFlight(double mileage);
    
    bool freeFlight(string from, string to, double mileage, PlaneFlight &flight);
    
};
#endif
