
#ifndef PLANEFLIGHT_H
#define PLANEFLIGHT_H
#include <iostream>
#include <string>
using namespace std;

class PlaneFlight
{
private:
    string mName;
    string mFromCity;
    string mToCity;
    double mCost;
    double mMileage;
    
   
public:
    PlaneFlight(string passengerName, string fromCity, string toCity, double cost, double mileage);
    
    PlaneFlight();
    
    string getName();
    string getFromCity();
    string getToCity();
    double getCost();
    double getMileage();
   
    void setName(string name);
    void setFromCity(string from, string to);
    void setToCity(string to);
    void setCost(double cost);
    void setMileage(double mileage);
    
};
#endif



